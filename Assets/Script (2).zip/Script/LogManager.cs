﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LogManager : MonoBehaviour
{
    public static LogManager Instance;
    private Queue<string> logQueue = new Queue<string>();
    private bool isPrinting = false;

    void Awake() { Instance = this; }

    public void EnqueueLog(string message)
    {
        logQueue.Enqueue(message);
        if (!isPrinting) StartCoroutine(ProcessQueue());
    }

    private IEnumerator ProcessQueue()
    {
        isPrinting = true;
        while (logQueue.Count > 0)
        {
            Debug.Log(logQueue.Dequeue());
            // 🚩 這裡控制全域所有 Log 的強制間隔
            yield return new WaitForSeconds(0.5f);
        }
        isPrinting = false;
    }
}