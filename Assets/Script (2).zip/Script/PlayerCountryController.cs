﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class PlayerCountryController : MonoBehaviour
{
    public CountryStateManager selfState;
    public CountryAIAgent backupAI; // 用於「切換」功能
    public bool isAutoMode = false;

    [Header("UI 引用")]
    public GameObject mainActionPanel;
    public Text apText;
    public Button popPolicyBtn;
    public Button milPolicyBtn;

    private Country GetMyData() => selfState.resource.countries.Find(c => c.CountryName == selfState.CountryName);

    void Update()
    {
        UpdateUI();
    }

    private void UpdateUI()
    {
        Country data = GetMyData();
        if (data == null) return;

        apText.text = $"AP: {data.AP}";

        // 政策按鈕顏色邏輯
        popPolicyBtn.image.color = selfState.policy.IsPolicyReady(selfState.CountryName, "Pop") ? Color.white : Color.red;
        milPolicyBtn.image.color = selfState.policy.IsPolicyReady(selfState.CountryName, "Mil") ? Color.white : Color.red;
    }

    public void OnPlayerTurnStart()
    {
        if (isAutoMode)
        {
            Debug.Log("<color=cyan>[玩家國]</color> 目前為 AI 代管模式...");
            backupAI.RequestDecision(); // 驅動 ML-Agents 動作
        }
        else
        {
            mainActionPanel.SetActive(true);
            Debug.Log("<color=green>[系統]</color> 輪到玩家行動。");
        }
    }

    // 5. 切換：將管理權交由 AI
    public void ToggleControlMode()
    {
        isAutoMode = !isAutoMode;
        if (isAutoMode) EndTurn();
    }

    // 4. 休息：結束回合
    public void EndTurn()
    {
        mainActionPanel.SetActive(false);
        GameManager.Instance.RegisterAgentAction();
    }

    // 執行動作並檢查 AP
    public void UseAP(int amount)
    {
        Country data = GetMyData();
        if (data.AP >= amount)
        {
            data.AP -= amount;
            if (data.AP <= 0) EndTurn(); // 行動點歸零強制結束
        }
    }

    // 2. 生育政策
    public void TriggerPopPolicy()
    {
        if (selfState.policy.IsPolicyReady(selfState.CountryName, "Pop"))
        {
            UseAP(1);
            selfState.policy.ApplyPopulationPolicy(GetMyData());
        }
    }

    // 3. 軍事政策
    public void TriggerMilPolicy()
    {
        if (selfState.policy.IsPolicyReady(selfState.CountryName, "Mil"))
        {
            UseAP(1);
            selfState.policy.ApplyMilitaryPolicy(GetMyData());
        }
    }
}