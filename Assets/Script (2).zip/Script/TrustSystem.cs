using UnityEngine;
using System.Collections.Generic;
//�H��Ȩt��
public class TrustSystem : MonoBehaviour
{
    private Dictionary<string, int> trustValues = new Dictionary<string, int>(); //��l�ƫH���
    private const int Min = -50;
    private const int Max = 100;
    //�H��ȳ̤j��100�A�̤p��-50
    public void InitializeTrusts(List<Country> countries, string selfName)
    {
        trustValues.Clear();
        foreach (var c in countries)
        {
            if (c.CountryName != selfName)
                trustValues[c.CountryName] = 50; // ��l�H���50
        }
    }
    public void ModifyTrust(string targetCountry, int amount)
    {
        if (!trustValues.ContainsKey(targetCountry)) return;
        trustValues[targetCountry] = Mathf.Clamp(trustValues[targetCountry] + amount, Min, Max);
    }
    public void SetTrust(string targetCountry, int value)
    {
        if (!trustValues.ContainsKey(targetCountry)) return;
        trustValues[targetCountry] = Mathf.Clamp(value, Min, Max);
    }
    public int GetTrust(string targetCountry)
    {
        if (!trustValues.ContainsKey(targetCountry)) return 0;
        return trustValues[targetCountry];
    }
    public bool CanTrade(string targetCountry) => GetTrust(targetCountry) >= 0;//�P�_�O�_�i�H���
    public bool CanEstablishRelations(string targetCountry) => GetTrust(targetCountry) > 50;//�P�_�O�_�i�H�إ�
    public bool CanAlliance(string targetCountry) => GetTrust(targetCountry) > 70;//�P�_�O�_�i�H�x�ƦP��
}